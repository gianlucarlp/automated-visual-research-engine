import json
from pathlib import Path
from .pexels import Pexels
from .pixabay import Pixabay
from .coverr import Coverr
from .wikimedia import Wikimedia
from core.media import score,cache_key

def _read_or_fetch(provider_name,media_type,query,fetch,cache_dir):
    cp=None
    if cache_dir:
        cp=Path(cache_dir)/f"{cache_key(provider_name,media_type,query)}.json"
        if cp.exists():
            try:return json.loads(cp.read_text(encoding="utf-8"))
            except:pass
    data=fetch()
    if cp:
        try:cp.write_text(json.dumps(data,ensure_ascii=False),encoding="utf-8")
        except:pass
    return data

def search_all(keys,queries,preferred="either",n=10,enabled=None,cache_dir=None):
    enabled=enabled or {}
    results={}
    errors=[]

    pex=Pexels(keys.get("pexels",""))
    pix=Pixabay(keys.get("pixabay",""))
    cov=Coverr(keys.get("coverr",""))
    wik=Wikimedia()

    # Search strategy by preferred media. 'archival' prioritizes Wikimedia but still allows fallback.
    tasks=[]
    for q in queries:
        if preferred in ("video","either"):
            if enabled.get("pexels_video",True) and keys.get("pexels"):
                tasks.append(("Pexels","video",q,lambda q=q:pex.search_video(q,n)))
            if enabled.get("pixabay_video",True) and keys.get("pixabay"):
                tasks.append(("Pixabay","video",q,lambda q=q:pix.search_video(q,n)))
            if enabled.get("coverr_video",True) and keys.get("coverr"):
                tasks.append(("Coverr","video",q,lambda q=q:cov.search_video(q,n)))

        if preferred in ("image","either","archival"):
            if enabled.get("pexels_image",True) and keys.get("pexels") and preferred!="archival":
                tasks.append(("Pexels","image",q,lambda q=q:pex.search_image(q,n)))
            if enabled.get("pixabay_image",True) and keys.get("pixabay") and preferred!="archival":
                tasks.append(("Pixabay","image",q,lambda q=q:pix.search_image(q,n)))

        if enabled.get("wikimedia",True):
            tasks.append(("Wikimedia Commons","mixed",q,lambda q=q:wik.search(q,n)))

    for provider,media_type,q,fetch in tasks:
        try:
            found=_read_or_fetch(provider,media_type,q,fetch,cache_dir)
        except Exception as e:
            errors.append(f"{provider} | {q} | {e}")
            continue

        for item in found:
            item["query"]=q
            item["score"]=score(item,q,preferred)
            if item["score"]<0:continue
            url=item.get("url")
            if url and (url not in results or item["score"]>results[url]["score"]):
                results[url]=item

    ranked=sorted(results.values(),key=lambda x:x["score"],reverse=True)

    # For strong media preference, keep that type first without eliminating fallbacks.
    if preferred=="video":
        ranked=sorted(ranked,key=lambda x:(x.get("media_type")!="video",-x["score"]))
    elif preferred in ("image","archival"):
        ranked=sorted(ranked,key=lambda x:(x.get("media_type")!="image",-x["score"]))

    return ranked,errors
