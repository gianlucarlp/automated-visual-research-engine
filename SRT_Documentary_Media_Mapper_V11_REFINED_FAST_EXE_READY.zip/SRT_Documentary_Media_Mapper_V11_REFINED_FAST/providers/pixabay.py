import requests

class Pixabay:
    name="Pixabay"
    def __init__(self,key): self.key=key

    def search_video(self,q,n=10):
        if not self.key:return []
        r=requests.get("https://pixabay.com/api/videos/",
            params={"key":self.key,"q":q,"per_page":n},timeout=45)
        r.raise_for_status()
        out=[]
        for v in r.json().get("hits",[]):
            variants=[x for x in v.get("videos",{}).values()
                      if isinstance(x,dict) and x.get("url") and x.get("width") and x.get("height")]
            if not variants:continue
            f=max(variants,key=lambda x:x["width"]*x["height"])
            out.append({
                "provider":self.name,"media_type":"video","id":v.get("id"),
                "title":v.get("tags",""),"description":v.get("tags",""),"tags":v.get("tags",""),
                "url":f["url"],"width":f["width"],"height":f["height"],
                "duration":v.get("duration",0),"page_url":v.get("pageURL"),
                "license_note":"Pixabay"
            })
        return out

    def search_image(self,q,n=10):
        if not self.key:return []
        r=requests.get("https://pixabay.com/api/",
            params={"key":self.key,"q":q,"per_page":n,"image_type":"photo",
                    "orientation":"horizontal","safesearch":"true"},timeout=45)
        r.raise_for_status()
        out=[]
        for p in r.json().get("hits",[]):
            url=p.get("largeImageURL") or p.get("webformatURL")
            w=p.get("imageWidth") or p.get("webformatWidth")
            h=p.get("imageHeight") or p.get("webformatHeight")
            if not (url and w and h):continue
            out.append({
                "provider":self.name,"media_type":"image","id":p.get("id"),
                "title":p.get("tags",""),"description":p.get("tags",""),"tags":p.get("tags",""),
                "url":url,"width":w,"height":h,"duration":0,
                "page_url":p.get("pageURL"),"license_note":"Pixabay"
            })
        return out
