import requests

class Coverr:
    name="Coverr"
    def __init__(self,key): self.key=key

    def search_video(self,q,n=10):
        if not self.key:return []
        headers={"Authorization":f"Bearer {self.key}","x-api-key":self.key}
        attempts=[
            ("https://api.coverr.co/videos/search",{"query":q,"page_size":n}),
            ("https://api.coverr.co/videos",{"query":q,"page_size":n})
        ]
        data=None; last=None
        for url,params in attempts:
            try:
                r=requests.get(url,headers=headers,params=params,timeout=45)
                if r.ok:
                    data=r.json();break
                last=f"{r.status_code} {r.text[:200]}"
            except Exception as e:
                last=str(e)
        if data is None:
            raise RuntimeError(last or "Falha Coverr")

        hits=data.get("hits") or data.get("videos") or data.get("results") or []
        out=[]
        for v in hits:
            variants=v.get("video_variants") or v.get("variants") or v.get("video_files") or []
            if isinstance(variants,dict):variants=list(variants.values())
            opts=[]
            for x in variants:
                if not isinstance(x,dict):continue
                url=x.get("url") or x.get("download_url") or x.get("src")
                w=x.get("width") or x.get("w"); h=x.get("height") or x.get("h")
                if url and w and h:opts.append((w*h,url,w,h))
            if not opts:
                url=v.get("video_url") or v.get("download_url") or v.get("url")
                w=v.get("width");h=v.get("height")
                if url and w and h:opts.append((w*h,url,w,h))
            if not opts:continue
            _,url,w,h=max(opts)
            out.append({
                "provider":self.name,"media_type":"video","id":v.get("id") or v.get("slug"),
                "title":v.get("title",""),"description":v.get("description",""),
                "tags":" ".join(v.get("tags",[])) if isinstance(v.get("tags"),list) else str(v.get("tags","")),
                "url":url,"width":w,"height":h,"duration":v.get("duration",0) or 0,
                "page_url":v.get("page_url") or v.get("url"),
                "license_note":"Coverr - confira atribuição/licença conforme sua conta"
            })
        return out
