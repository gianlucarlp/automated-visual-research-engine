import requests
from core.media import clean_html

class Wikimedia:
    name="Wikimedia Commons"
    API="https://commons.wikimedia.org/w/api.php"

    def search(self,q,n=10):
        params={
            "action":"query","format":"json",
            "generator":"search","gsrsearch":q,
            "gsrnamespace":6,"gsrlimit":min(max(n*4,20),50),
            "prop":"imageinfo",
            "iiprop":"url|size|mime|extmetadata"
        }
        r=requests.get(self.API,params=params,
            headers={"User-Agent":"SRT-Documentary-Media-Mapper/5.0 (desktop documentary app)"},
            timeout=60)
        r.raise_for_status()
        pages=r.json().get("query",{}).get("pages",{})
        out=[]
        for p in pages.values():
            ii=(p.get("imageinfo") or [{}])[0]
            mime=(ii.get("mime") or "").lower()
            if not (mime.startswith("image/") or mime.startswith("video/") or mime=="application/ogg"):
                continue
            url=ii.get("url");w=ii.get("width");h=ii.get("height")
            if not (url and w and h):continue
            meta=ii.get("extmetadata") or {}
            desc=clean_html((meta.get("ImageDescription") or {}).get("value",""))
            artist=clean_html((meta.get("Artist") or {}).get("value",""))
            license_name=clean_html((meta.get("LicenseShortName") or {}).get("value",""))
            license_url=clean_html((meta.get("LicenseUrl") or {}).get("value",""))
            credit=clean_html((meta.get("Credit") or {}).get("value",""))
            media_type="video" if (mime.startswith("video/") or mime=="application/ogg") else "image"
            out.append({
                "provider":self.name,"media_type":media_type,"id":p.get("pageid"),
                "title":p.get("title",""),"description":desc,"tags":q,
                "url":url,"width":w,"height":h,"duration":0,
                "page_url":ii.get("descriptionurl"),
                "author":artist,"license":license_name,"license_url":license_url,
                "credit":credit,
                "license_note":" | ".join(x for x in [license_name,artist] if x)
            })
            if len(out)>=n:break
        return out
