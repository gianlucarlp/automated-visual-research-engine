import requests

class Pexels:
    name="Pexels"
    def __init__(self,key): self.key=key

    def search_video(self,q,n=10):
        if not self.key:return []
        r=requests.get("https://api.pexels.com/v1/videos/search",
            headers={"Authorization":self.key},
            params={"query":q,"per_page":n,"orientation":"landscape"},timeout=45)
        r.raise_for_status()
        out=[]
        for v in r.json().get("videos",[]):
            files=[x for x in v.get("video_files",[]) if x.get("link") and x.get("width") and x.get("height")]
            if not files:continue
            f=max(files,key=lambda x:x["width"]*x["height"])
            out.append({
                "provider":self.name,"media_type":"video","id":v.get("id"),
                "title":v.get("url",""),"description":"","tags":q,
                "url":f["link"],"width":f["width"],"height":f["height"],
                "duration":v.get("duration",0),"page_url":v.get("url"),
                "license_note":"Pexels"
            })
        return out

    def search_image(self,q,n=10):
        if not self.key:return []
        r=requests.get("https://api.pexels.com/v1/search",
            headers={"Authorization":self.key},
            params={"query":q,"per_page":n,"orientation":"landscape"},timeout=45)
        r.raise_for_status()
        out=[]
        for p in r.json().get("photos",[]):
            src=p.get("src") or {}
            url=src.get("original") or src.get("large2x") or src.get("large")
            w=p.get("width"); h=p.get("height")
            if not (url and w and h):continue
            out.append({
                "provider":self.name,"media_type":"image","id":p.get("id"),
                "title":p.get("alt",""),"description":p.get("alt",""),"tags":q,
                "url":url,"width":w,"height":h,"duration":0,
                "page_url":p.get("url"),"license_note":"Pexels"
            })
        return out
