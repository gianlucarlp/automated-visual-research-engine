import json,os,threading,traceback,sys
from pathlib import Path
import tkinter as tk
from tkinter import ttk,filedialog,messagebox

from core.srt import parse_srt,build_scenes
from core.ai import analyze
from core.media import download,extension_for
from core.ffmpeg_tools import ffmpeg_available, trim_video_to_duration, image_to_video, media_duration
from providers.search import search_all
from core.refinement import apply_refinement, build_query_ladder

APP_DIR=Path(sys.executable).resolve().parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent.parent
RESOURCE_DIR=Path(getattr(sys,"_MEIPASS",APP_DIR))

DEFAULT_CONFIG={
 "ai_provider":"gemini","openai_model":"gpt-5.6","gemini_model":"gemini-2.5-flash",
 "scene_max_seconds":12,"max_queries_per_scene":8,"max_fallback_queries":5,
 "candidates_per_provider_per_query":10,"downloads_per_scene":1,
 "target_width":1920,"target_height":1080,"use_cache":True,"hybrid_mode":"auto",
 "manual_video_percent":65,"manual_image_percent":35,
 "providers":{"pexels_video":True,"pexels_image":True,"pixabay_video":True,"pixabay_image":True,
              "coverr_video":True,"wikimedia":True},
 "trim_to_srt_duration":True,"flat_output":True,"keep_original_downloads":False,"image_render_fps":30,"smart_cut_enabled":True,"smart_cut_samples":9,"smart_cut_head_tail_margin":0.35,"ai_batch_size":6,"ai_max_retries":4,"ai_connect_timeout":20,"ai_read_timeout":180,"ai_retry_base_seconds":3,"ai_cache":True,"ai_continue_on_failure":True
}

def load_config():
    for p in [APP_DIR/"config"/"default.json",RESOURCE_DIR/"config"/"default.json"]:
        try:
            if p.exists():
                data=json.loads(p.read_text(encoding="utf-8"))
                merged={**DEFAULT_CONFIG,**data}
                merged["providers"]={**DEFAULT_CONFIG["providers"],**data.get("providers",{})}
                return merged
        except:
            pass
    return DEFAULT_CONFIG.copy()

class App:
    def __init__(self,root):
        self.root=root
        root.title("SRT Documentary Media Mapper V11 REFINED FAST")
        root.geometry("1180x890")
        root.minsize(980,720)
        self.cfg=load_config()

        self.srt=tk.StringVar()
        self.ai=tk.StringVar(value=self.cfg["ai_provider"])
        self.hybrid=tk.StringVar(value=self.cfg.get("hybrid_mode","auto"))
        self.openai=tk.StringVar(value=os.getenv("OPENAI_API_KEY",""))
        self.gemini=tk.StringVar(value=os.getenv("GEMINI_API_KEY",""))
        self.pexels=tk.StringVar(value=os.getenv("PEXELS_API_KEY",""))
        self.pixabay=tk.StringVar(value=os.getenv("PIXABAY_API_KEY",""))
        self.coverr=tk.StringVar(value=os.getenv("COVERR_API_KEY",""))
        self.downloads=tk.IntVar(value=self.cfg["downloads_per_scene"])
        self.economy=tk.BooleanVar(value=bool(self.cfg.get("economy_mode",True)))
        self.smart_mode=tk.StringVar(value=self.cfg.get("smart_cut_mode","fast"))
        self.progress=tk.DoubleVar(value=0)
        self.status=tk.StringVar(value="Pronto.")
        self.build_ui()

    def build_ui(self):
        top=ttk.Frame(self.root,padding=12);top.pack(fill="x")
        ttk.Label(top,text="SRT DOCUMENTARY MEDIA MAPPER V11 REFINED FAST",
                  font=("Segoe UI",18,"bold")).pack(anchor="w")
        ttk.Label(top,text="IA decide entre vídeo, imagem e arquivo histórico • 16:9 • downloads separados por cena").pack(anchor="w")

        f=ttk.LabelFrame(self.root,text="1. SRT",padding=10);f.pack(fill="x",padx=12,pady=5)
        ttk.Entry(f,textvariable=self.srt).pack(side="left",fill="x",expand=True)
        ttk.Button(f,text="Selecionar SRT",command=self.pick).pack(side="left",padx=6)

        f=ttk.LabelFrame(self.root,text="2. Inteligência Artificial",padding=10);f.pack(fill="x",padx=12,pady=5)
        ttk.Label(f,text="IA").grid(row=0,column=0,sticky="w")
        ttk.Combobox(f,textvariable=self.ai,values=["gemini","openai"],state="readonly",width=14).grid(row=0,column=1,sticky="w",padx=5)
        ttk.Label(f,text="OpenAI modelo").grid(row=0,column=4,sticky="e",padx=(20,5))
        self.openai_model=tk.StringVar(value=self.cfg.get("openai_model","gpt-5.4-mini"))
        ttk.Combobox(f,textvariable=self.openai_model,
                     values=["gpt-5.4-mini","gpt-5.6"],state="readonly",width=16).grid(row=0,column=5,sticky="w")
        ttk.Label(f,text="Modo visual").grid(row=0,column=2,sticky="e",padx=(25,5))
        ttk.Combobox(f,textvariable=self.hybrid,values=["auto","video","image","either"],state="readonly",width=14).grid(row=0,column=3,sticky="w")

        ttk.Label(f,text="OpenAI API").grid(row=1,column=0,sticky="w",pady=3)
        ttk.Entry(f,textvariable=self.openai,show="*",width=80).grid(row=1,column=1,columnspan=3,sticky="ew",padx=5)
        ttk.Label(f,text="Gemini API").grid(row=2,column=0,sticky="w",pady=3)
        ttk.Entry(f,textvariable=self.gemini,show="*",width=80).grid(row=2,column=1,columnspan=3,sticky="ew",padx=5)
        f.columnconfigure(1,weight=1)

        f=ttk.LabelFrame(self.root,text="3. Bancos de mídia",padding=10);f.pack(fill="x",padx=12,pady=5)
        for row,(label,var) in enumerate([
            ("Pexels API",self.pexels),("Pixabay API",self.pixabay),("Coverr API",self.coverr)
        ]):
            ttk.Label(f,text=label).grid(row=row,column=0,sticky="w")
            ttk.Entry(f,textvariable=var,show="*",width=80).grid(row=row,column=1,columnspan=3,sticky="ew",padx=5,pady=2)
        ttk.Label(f,text="Wikimedia Commons").grid(row=3,column=0,sticky="w")
        ttk.Label(f,text="✓ Sem API key • imagens, fotos históricas, mapas, pinturas e alguns vídeos").grid(row=3,column=1,columnspan=3,sticky="w")
        ttk.Label(f,text="Downloads por cena").grid(row=4,column=0,sticky="w",pady=4)
        ttk.Spinbox(f,from_=1,to=5,textvariable=self.downloads,width=8).grid(row=4,column=1,sticky="w")
        ttk.Label(f,text="Formato: landscape / compatível com 16:9").grid(row=4,column=2,columnspan=2,sticky="e")
        f.columnconfigure(1,weight=1)

        info=ttk.LabelFrame(self.root,text="Estratégia",padding=10);info.pack(fill="x",padx=12,pady=5)
        ttk.Label(info,text="AUTO: a IA escolhe VIDEO / IMAGE / ARCHIVAL / EITHER por cena. "
                            "Se houver poucos resultados, o aplicativo ativa consultas de fallback e outras fontes.",
                  wraplength=1080).pack(anchor="w")
        row=ttk.Frame(info); row.pack(fill="x",pady=(6,0))
        ttk.Checkbutton(row,text="ECONOMY MODE (menos tokens e menos buscas)",variable=self.economy).pack(side="left")
        ttk.Label(row,text="Smart Cut:").pack(side="left",padx=(30,5))
        ttk.Combobox(row,textvariable=self.smart_mode,
                     values=["fast","center","off"],state="readonly",width=10).pack(side="left")
        ttk.Label(row,text="FAST = 3 análises rápidas | CENTER = sem análise | OFF = início do vídeo").pack(side="left",padx=10)

        f=ttk.Frame(self.root,padding=(12,8));f.pack(fill="x")
        self.btn=ttk.Button(f,text="ANALISAR SRT + MAPEAR + BAIXAR MÍDIA",command=self.start)
        self.btn.pack(fill="x",ipady=9)
        ttk.Progressbar(f,variable=self.progress,maximum=100).pack(fill="x",pady=7)
        ttk.Label(f,textvariable=self.status).pack(anchor="w")

        lf=ttk.LabelFrame(self.root,text="Log",padding=8);lf.pack(fill="both",expand=True,padx=12,pady=5)
        self.log=tk.Text(lf,font=("Consolas",9),wrap="word")
        self.log.pack(side="left",fill="both",expand=True)
        sb=ttk.Scrollbar(lf,command=self.log.yview);sb.pack(side="right",fill="y")
        self.log.configure(yscrollcommand=sb.set)

    def pick(self):
        p=filedialog.askopenfilename(filetypes=[("SubRip SRT","*.srt"),("Todos","*.*")])
        if p:self.srt.set(p)

    def write(self,msg):
        self.log.insert("end",msg+"\n")
        self.log.see("end")
        self.root.update_idletasks()

    def start(self):
        if not self.srt.get() or not Path(self.srt.get()).exists():
            messagebox.showwarning("SRT","Selecione um arquivo SRT válido.");return
        ai_key=self.openai.get() if self.ai.get()=="openai" else self.gemini.get()
        if not ai_key:
            messagebox.showwarning("IA","Informe a API key da IA selecionada.");return
        self.btn.config(state="disabled")
        self.log.delete("1.0","end")
        self.progress.set(0)
        threading.Thread(target=self.worker,daemon=True).start()

    def worker(self):
        try:
            srt_path=Path(self.srt.get())
            subs=parse_srt(srt_path)
            scenes=build_scenes(subs,self.cfg["scene_max_seconds"])
            self.write(f"{len(subs)} legendas → {len(scenes)} cenas.")
            self.progress.set(5)

            key=self.openai.get() if self.ai.get()=="openai" else self.gemini.get()
            model=self.cfg["openai_model"] if self.ai.get()=="openai" else self.cfg["gemini_model"]

            intelligence={}
            batch_size=max(1,int(self.cfg.get("ai_batch_size",6)))
            ai_cache_dir=APP_DIR/"cache"/"ai" if self.cfg.get("ai_cache",True) else None

            if self.ai.get()=="openai":
                model=self.openai_model.get() if hasattr(self,"openai_model") else self.cfg.get("openai_model","gpt-5.4-mini")

            def retry_log(attempt,max_retries,error,delay):
                self.write(f"  ↳ IA timeout/erro. Retry {attempt+1}/{max_retries} em {delay}s...")
                self.write(f"     {error[:160]}")

            for i in range(0,len(scenes),batch_size):
                chunk=scenes[i:i+batch_size]
                self.write(f"IA: analisando cenas {i+1}-{min(i+batch_size,len(scenes))} com {model}...")
                data=analyze(
                    self.ai.get(),key,model,chunk,
                    cache_dir=ai_cache_dir,
                    connect_timeout=int(self.cfg.get("ai_connect_timeout",20)),
                    read_timeout=int(self.cfg.get("ai_read_timeout",180)),
                    max_retries=int(self.cfg.get("ai_max_retries",4)),
                    retry_base=int(self.cfg.get("ai_retry_base_seconds",3)),
                    on_retry=retry_log,
                    continue_on_failure=bool(self.cfg.get("ai_continue_on_failure",True))
                )
                fallback_used=bool(data.get("_fallback"))
                for x in data.get("scenes",[]):
                    intelligence[int(x["id"])]=x
                if fallback_used:
                    self.write(f"⚠ Cenas {i+1}-{min(i+batch_size,len(scenes))}: IA indisponível; queries locais de fallback usadas.")
                else:
                    self.write(f"✓ IA analisou cenas {i+1}-{min(i+batch_size,len(scenes))}.")
                self.progress.set(5+15*min(i+batch_size,len(scenes))/max(1,len(scenes)))

            outdir=APP_DIR/"output"/srt_path.stem
            outdir.mkdir(parents=True,exist_ok=True)
            cache_dir=APP_DIR/"cache" if self.cfg.get("use_cache") else None

            mapping={
                "source_srt":str(srt_path.resolve()),
                "target":"16:9 / 1920x1080",
                "mode":self.hybrid.get(),
                "scenes":[]
            }
            credits=[]
            used_urls=set()
            recent_provider_types=[]

            keys={"pexels":self.pexels.get(),"pixabay":self.pixabay.get(),"coverr":self.coverr.get()}

            for pos,scene in enumerate(scenes,1):
                info=intelligence.get(scene.id,{})
                ai_pref=(info.get("preferred_media") or "either").lower()
                preferred=ai_pref if self.hybrid.get()=="auto" else self.hybrid.get()
                if preferred not in ("video","image","archival","either"):
                    preferred="either"

                query_limit=4 if self.economy.get() else int(self.cfg.get("max_queries_per_scene",8))
                fallback_limit=2 if self.economy.get() else int(self.cfg.get("max_fallback_queries",5))
                primary=info.get("queries",[])[:query_limit]
                fallback=info.get("fallback_queries",[])[:fallback_limit]

                self.write(f"\n[CENA {scene.id:03d}] {scene.duration:.1f}s | preferência: {preferred.upper()}")
                self.write(scene.text)
                self.write("Queries: "+" | ".join(primary))

                errors=[]
                candidates=[]
                ladder=build_query_ladder(
                    info,primary,fallback,
                    int(self.cfg.get("query_ladder_levels",3))
                ) if self.cfg.get("query_ladder_enabled",True) else [primary]

                min_candidates=int(self.cfg.get("query_ladder_min_candidates",5))

                for level_no,level_queries in enumerate(ladder,1):
                    if not level_queries:
                        continue
                    self.write(f"  ↳ Query ladder nível {level_no}: " + " | ".join(level_queries))
                    found,err=search_all(
                        keys,level_queries,preferred,
                        (7 if self.economy.get() else self.cfg["candidates_per_provider_per_query"]),
                        self.cfg["providers"],cache_dir
                    )
                    errors+=err

                    byurl={x["url"]:x for x in candidates if x.get("url")}
                    for x in found:
                        if x.get("url") and (x["url"] not in byurl or x["score"]>byurl[x["url"]]["score"]):
                            byurl[x["url"]]=x
                    candidates=list(byurl.values())

                    # Early exit preserves speed.
                    if len(candidates)>=min_candidates:
                        break

                candidates=apply_refinement(
                    candidates,
                    must_have=info.get("must_have",[]),
                    avoid=info.get("avoid",[]),
                    used_urls=used_urls if self.cfg.get("anti_repeat_enabled",True) else set(),
                    recent_provider_types=recent_provider_types[-int(self.cfg.get("diversity_recent_scenes",5)):],
                    diversity=bool(self.cfg.get("diversity_enabled",True))
                )

                candidates=candidates[:int(self.cfg.get("candidate_pool_limit",30))]
                self.write(f"{len(candidates)} candidatos após refinamento/anti-repetição.")
                if candidates:
                    self.write(f"  ↳ melhor confiança: {candidates[0].get('confidence',0):.1f}/100")

                downloaded=[]
                min_conf=float(self.cfg.get("semantic_confidence_threshold",58))
                if candidates and candidates[0].get("confidence",0) < min_conf:
                    self.write(f"⚠ Baixa confiança ({candidates[0].get('confidence',0):.1f}). Melhor opção disponível será usada.")

                scene_manifest_path=outdir/f"scene_{scene.id:03d}_manifest.json"

                for rank,item in enumerate(candidates[:self.downloads.get()],1):
                    ext=extension_for(item)
                    kind="video" if item.get("media_type")=="video" else "image"

                    # Temporary/original file. It is removed after normalization unless configured otherwise.
                    temp_dir=APP_DIR/"cache"/"originals"
                    temp_dir.mkdir(parents=True,exist_ok=True)
                    raw_dest=temp_dir/f"scene_{scene.id:03d}_{rank:02d}_{kind}{ext}"

                    # Flat output for direct CapCut import.
                    final_dest=outdir/f"{scene.id:03d}_scene_{scene.id:03d}_{rank:02d}.mp4"

                    try:
                        download(item["url"],raw_dest)

                        if not ffmpeg_available():
                            raise RuntimeError(
                                "FFmpeg não encontrado. Instale o FFmpeg e adicione-o ao PATH "
                                "para ajustar as cenas à duração do SRT."
                            )

                        if item.get("media_type")=="video":
                            original_duration=media_duration(raw_dest)
                            _, smart_segment = trim_video_to_duration(
                                raw_dest,final_dest,scene.duration,1920,1080,
                                smart_cut=(self.smart_mode.get()!="off"),
                                smart_cut_samples=(3 if self.smart_mode.get()=="fast" else int(self.cfg.get("smart_cut_samples",3))),
                                head_tail_margin=float(self.cfg.get("smart_cut_head_tail_margin",0.35)),
                                smart_cut_mode=self.smart_mode.get(),
                                probe_seconds=float(self.cfg.get("smart_cut_probe_seconds",1.35)),
                                minimum_ratio=float(self.cfg.get("smart_cut_only_if_source_ratio",1.65))
                            )
                            item["original_duration"]=original_duration
                            item["timeline_duration"]=scene.duration
                            item["trimmed_to_srt"]=True
                            item["smart_cut"]=smart_segment
                            self.write(
                                f"  ↳ corte {smart_segment.get('mode','fast')}: {smart_segment.get('start',0):.3f}s "
                                f"→ {smart_segment.get('start',0)+scene.duration:.3f}s "
                                f"| score {smart_segment.get('score',0)}"
                            )
                        else:
                            image_to_video(
                                raw_dest,final_dest,scene.duration,1920,1080,
                                int(self.cfg.get("image_render_fps",30))
                            )
                            item["original_duration"]=None
                            item["timeline_duration"]=scene.duration
                            item["image_rendered_to_video"]=True

                        item["local_file"]=str(final_dest.resolve())
                        downloaded.append(item)
                        if item.get("url"):
                            used_urls.add(item.get("url"))
                        recent_provider_types.append(f"{item.get('provider')}:{item.get('media_type')}")

                        self.write(
                            f"✓ {item['provider']} | {item['media_type']} | "
                            f"{scene.duration:.3f}s | 1920x1080 | {final_dest.name}"
                        )

                        if not self.cfg.get("keep_original_downloads",False):
                            try:
                                raw_dest.unlink(missing_ok=True)
                            except:
                                pass

                        if item.get("provider")=="Wikimedia Commons":
                            credits.append({
                                "scene":scene.id,"title":item.get("title"),"author":item.get("author"),
                                "license":item.get("license"),"license_url":item.get("license_url"),
                                "source":item.get("page_url")
                            })
                    except Exception as e:
                        self.write(f"✗ processamento: {item['provider']} | {e}")

                manifest={
                    "id":scene.id,"start":scene.start,"end":scene.end,"duration":scene.duration,
                    "text":scene.text,"preferred_media":preferred,"ai":info,
                    "queries":primary,"fallback_queries":fallback,
                    "candidates":candidates[:50],"downloaded":downloaded,"errors":errors
                }
                scene_manifest_path.write_text(
                    json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
                mapping["scenes"].append(manifest)
                self.progress.set(20+80*pos/max(1,len(scenes)))

            (outdir/"mapping.json").write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding="utf-8")
            (outdir/"credits.json").write_text(json.dumps(credits,ensure_ascii=False,indent=2),encoding="utf-8")

            # Human-readable credits
            credit_lines=["WIKIMEDIA / ARCHIVAL CREDITS",""]
            for c in credits:
                credit_lines.append(f"Scene {c.get('scene')}: {c.get('title')}")
                credit_lines.append(f"Author: {c.get('author') or '-'}")
                credit_lines.append(f"License: {c.get('license') or '-'}")
                credit_lines.append(f"Source: {c.get('source') or '-'}")
                credit_lines.append("")
            (outdir/"CREDITS.txt").write_text("\n".join(credit_lines),encoding="utf-8")

            self.status.set(f"Concluído: {outdir}")
            self.write("\n====================================")
            self.write("CONCLUÍDO")
            self.write(str(outdir.resolve()))
            self.write("Todas as cenas finais estão na mesma pasta, prontas para importar no CapCut.")
            self.write("CREDITS.txt criado para mídia Wikimedia.")
            self.write("====================================")
            self.root.after(0,lambda:messagebox.showinfo("Concluído",f"Mídia baixada em:\n{outdir.resolve()}"))
        except Exception as e:
            self.write("\nERRO:\n"+traceback.format_exc())
            self.status.set("Erro. Veja o log.")
            self.root.after(0,lambda:messagebox.showerror("Erro",str(e)))
        finally:
            self.root.after(0,lambda:self.btn.config(state="normal"))

if __name__=="__main__":
    root=tk.Tk()
    try:ttk.Style().theme_use("vista")
    except:pass
    App(root)
    root.mainloop()
