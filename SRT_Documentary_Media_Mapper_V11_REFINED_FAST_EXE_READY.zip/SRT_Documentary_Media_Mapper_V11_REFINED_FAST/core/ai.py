import json,re,requests,time,hashlib
from pathlib import Path

SYSTEM = """You are a senior visual director for YouTube documentary videos.
For each SRT scene, use the current scene plus neighboring context to decide the best visual representation and create stock/archive search intelligence.

Return ONLY valid JSON.
For each scene also include:
"must_have":["visible concepts that should appear"],
"avoid":["visible concepts that should not appear"],
"query_ladder":[["specific queries"],["broader queries"],["fallback queries"]].

{
  "scenes":[
    {
      "id":1,
      "visual_concept":"...",
      "preferred_media":"video|image|archival|either",
      "reason":"...",
      "queries":["..."],
      "fallback_queries":["..."],
      "subjects":["..."],
      "actions":["..."],
      "locations":["..."],
      "historical_entities":["..."]
    }
  ]
}

Rules:
- Search queries MUST be in English.
- Queries must describe visible things, people, places, objects, actions, environments, eras or archival subjects.
- Create exactly 4 concise primary queries and at most 2 fallback queries.
- Keep queries extremely short, normally 2-5 words. Avoid explanations unless essential.
- Prefer VIDEO for motion, atmosphere, landscapes, modern actions and natural events.
- Prefer IMAGE for portraits, paintings, manuscripts, historical photos, maps, diagrams, artifacts and specific historical figures/events.
- Prefer ARCHIVAL when exact historical imagery is more valuable than generic stock footage.
- Use EITHER when both video and image can represent the scene well.
- Avoid abstract wording and do not copy the SRT sentence verbatim.
"""

RETRY_STATUS = {408,409,429,500,502,503,504}

def _extract(text):
    text=(text or "").strip()
    text=re.sub(r"^```(?:json)?","",text).strip()
    text=re.sub(r"```$","",text).strip()
    a=text.find("{"); b=text.rfind("}")
    if a>=0 and b>a:
        return json.loads(text[a:b+1])
    raise ValueError("A IA não retornou JSON válido.")

def _scene_payload(scenes):
    payload=[]
    for i,s in enumerate(scenes):
        payload.append({
            "id":s.id,
            "text":s.text,
            "duration":s.duration,
            "previous_context":scenes[i-1].text if i>0 else "",
            "next_context":scenes[i+1].text if i+1<len(scenes) else ""
        })
    return payload

def _cache_key(provider,model,scenes):
    raw=json.dumps([provider,model,_scene_payload(scenes)],ensure_ascii=False,sort_keys=True)
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()

def _cache_read(cache_dir,key):
    if not cache_dir:return None
    p=Path(cache_dir)/f"{key}.json"
    if not p.exists():return None
    try:return json.loads(p.read_text(encoding="utf-8"))
    except:return None

def _cache_write(cache_dir,key,data):
    if not cache_dir:return
    p=Path(cache_dir)
    p.mkdir(parents=True,exist_ok=True)
    (p/f"{key}.json").write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")

def _fallback_scene(scene):
    # Last-resort local fallback so one API failure never kills an entire project.
    words=re.findall(r"[A-Za-zÀ-ÿ0-9'-]+", scene.text)
    useful=[]
    stop={"the","and","for","with","that","this","from","into","was","were","are","is","of","to","in","on","a","an",
          "de","da","do","das","dos","para","com","uma","um","que","e","o","a","os","as"}
    for w in words:
        lw=w.lower()
        if len(lw)>=3 and lw not in stop and lw not in useful:
            useful.append(lw)
    base=" ".join(useful[:5]) or scene.text[:80]
    q=[
        base,
        " ".join(useful[:3])+" documentary",
        " ".join(useful[:3])+" cinematic",
        " ".join(useful[:2])+" historical",
        " ".join(useful[:2])+" landscape"
    ]
    q=[x.strip() for x in q if x.strip()]
    return {
        "id":scene.id,
        "visual_concept":base,
        "preferred_media":"either",
        "reason":"local fallback after AI request failure",
        "queries":list(dict.fromkeys(q))[:5],
        "fallback_queries":list(dict.fromkeys([
            " ".join(useful[:2]),
            " ".join(useful[:2])+" archive",
            " ".join(useful[:2])+" stock footage"
        ]))[:3],
        "subjects":useful[:3],
        "actions":[],
        "locations":[],
        "historical_entities":[],"must_have":useful[:3],"avoid":[],"query_ladder":[q[:2],q[2:4],q[4:5]]
    }

def _request_with_retry(method,url,*,headers,json_body,timeout,max_retries,retry_base,on_retry=None):
    last=None
    for attempt in range(1,max_retries+1):
        try:
            r=requests.request(method,url,headers=headers,json=json_body,timeout=timeout)
            if r.status_code in RETRY_STATUS:
                last=RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
                if attempt < max_retries:
                    delay=min(30,retry_base*(2**(attempt-1)))
                    if on_retry:on_retry(attempt,max_retries,str(last),delay)
                    time.sleep(delay)
                    continue
            r.raise_for_status()
            return r
        except (requests.exceptions.Timeout,
                requests.exceptions.ConnectionError,
                requests.exceptions.ChunkedEncodingError) as e:
            last=e
            if attempt < max_retries:
                delay=min(30,retry_base*(2**(attempt-1)))
                if on_retry:on_retry(attempt,max_retries,str(e),delay)
                time.sleep(delay)
                continue
            raise
        except requests.exceptions.HTTPError:
            raise
    if last: raise last
    raise RuntimeError("Falha desconhecida na API.")

def ask_openai(api_key,model,scenes,*,connect_timeout=20,read_timeout=180,max_retries=4,retry_base=3,on_retry=None):
    prompt=SYSTEM+"\n\nSCENES:\n"+json.dumps(_scene_payload(scenes),ensure_ascii=False)
    r=_request_with_retry(
        "POST","https://api.openai.com/v1/responses",
        headers={"Authorization":f"Bearer {api_key}","Content-Type":"application/json"},
        json_body={"model":model,"input":prompt,"store":False,"max_output_tokens":2400},
        timeout=(connect_timeout,read_timeout),
        max_retries=max_retries,retry_base=retry_base,on_retry=on_retry
    )
    data=r.json()
    text=data.get("output_text","")
    if not text:
        parts=[]
        for item in data.get("output",[]):
            for c in item.get("content",[]):
                if c.get("type")=="output_text":
                    parts.append(c.get("text",""))
        text="".join(parts)
    return _extract(text)

def ask_gemini(api_key,model,scenes,*,connect_timeout=20,read_timeout=180,max_retries=4,retry_base=3,on_retry=None):
    prompt=SYSTEM+"\n\nSCENES:\n"+json.dumps(_scene_payload(scenes),ensure_ascii=False)
    url=f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    r=_request_with_retry(
        "POST",url,
        headers={"x-goog-api-key":api_key,"Content-Type":"application/json"},
        json_body={"contents":[{"parts":[{"text":prompt}]}],"generationConfig":{"temperature":0.15}},
        timeout=(connect_timeout,read_timeout),
        max_retries=max_retries,retry_base=retry_base,on_retry=on_retry
    )
    data=r.json()
    return _extract(data["candidates"][0]["content"]["parts"][0]["text"])

def analyze(provider,key,model,scenes,*,cache_dir=None,connect_timeout=20,read_timeout=180,
            max_retries=4,retry_base=3,on_retry=None,continue_on_failure=True):
    if not key:
        raise ValueError("Informe a API key da IA.")

    ck=_cache_key(provider,model,scenes)
    cached=_cache_read(cache_dir,ck)
    if cached:
        return cached

    try:
        if provider=="openai":
            data=ask_openai(key,model,scenes,connect_timeout=connect_timeout,read_timeout=read_timeout,
                            max_retries=max_retries,retry_base=retry_base,on_retry=on_retry)
        else:
            data=ask_gemini(key,model,scenes,connect_timeout=connect_timeout,read_timeout=read_timeout,
                            max_retries=max_retries,retry_base=retry_base,on_retry=on_retry)
        _cache_write(cache_dir,ck,data)
        return data
    except Exception:
        if not continue_on_failure:
            raise
        data={"scenes":[_fallback_scene(s) for s in scenes],"_fallback":True}
        _cache_write(cache_dir,ck,data)
        return data
