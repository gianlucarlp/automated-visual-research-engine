import subprocess, shutil, os, sys, re
from pathlib import Path

def app_dir():
    return Path(sys.executable).resolve().parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent.parent

def _which(name):
    exe = name if name.lower().endswith(".exe") else name+".exe"
    portable = app_dir()/"bin"/exe
    if portable.exists():
        return str(portable)
    dev = Path(__file__).resolve().parent.parent/"bin"/exe
    if dev.exists():
        return str(dev)
    return shutil.which(name)

def _hidden_kwargs():
    """Prevents ffmpeg/ffprobe console windows from flashing on Windows."""
    kwargs={}
    if os.name=="nt":
        CREATE_NO_WINDOW = getattr(subprocess,"CREATE_NO_WINDOW",0x08000000)
        kwargs["creationflags"]=CREATE_NO_WINDOW
        si=subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        kwargs["startupinfo"]=si
    return kwargs

def ffmpeg_available():
    return _which("ffmpeg") is not None

def ffprobe_available():
    return _which("ffprobe") is not None

def _run(cmd, capture=False, check=False):
    kwargs=_hidden_kwargs()
    if capture:
        return subprocess.run(
            cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
            text=True,check=check,**kwargs
        )
    return subprocess.run(
        cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
        check=check,**kwargs
    )

def media_duration(path):
    exe=_which("ffprobe")
    if not exe:return None
    cmd=[exe,"-v","error","-show_entries","format=duration",
         "-of","default=noprint_wrappers=1:nokey=1",str(path)]
    try:
        p=_run(cmd,capture=True,check=False)
        return float((p.stdout or "").strip())
    except:
        return None

def _motion_score(path,start,duration):
    """
    FAST SMART CUT: one short FFmpeg probe per candidate.
    Uses frame differences only, rather than 3 separate analyses per candidate.
    """
    exe=_which("ffmpeg")
    if not exe:return 0.0
    cmd=[
        exe,"-hide_banner",
        "-ss",f"{start:.3f}","-t",f"{duration:.3f}",
        "-i",str(path),
        "-vf","fps=6,tblend=all_mode=difference,signalstats,metadata=print",
        "-an","-f","null","-"
    ]
    p=_run(cmd,capture=True,check=False)
    text=(p.stdout or "")+"\n"+(p.stderr or "")
    vals=[]
    for line in text.splitlines():
        if "lavfi.signalstats.YAVG=" in line:
            try:
                vals.append(float(line.split("lavfi.signalstats.YAVG=")[-1].strip()))
            except:
                pass
    return sum(vals)/len(vals) if vals else 0.0

def choose_fast_segment(path,target_duration,samples=3,probe_seconds=1.35,minimum_ratio=1.65):
    total=media_duration(path)
    if not total or total <= target_duration + 0.08:
        return {"start":0.0,"source_duration":total,"target_duration":target_duration,
                "score":0.0,"mode":"none","reason":"source_not_longer"}

    max_start=max(0.0,total-target_duration)

    # If source is only modestly longer, central cut is faster and usually better
    # than launching analysis processes.
    if total / max(target_duration,0.01) < minimum_ratio:
        start=max_start/2
        return {"start":round(start,3),"source_duration":total,"target_duration":target_duration,
                "score":0.0,"mode":"center","reason":"source_only_slightly_longer"}

    # Three strategic windows by default: early-middle, center, late-middle.
    if samples <= 3:
        fractions=[0.18,0.50,0.82]
    else:
        fractions=[0.15 + 0.70*i/(samples-1) for i in range(samples)]

    probe=min(max(0.7,probe_seconds),target_duration,2.0)
    candidates=[]
    for frac in fractions:
        start=max_start*frac
        motion=_motion_score(path,start,probe)

        # Small centrality reward. No extra FFmpeg call.
        center=(start+target_duration/2)/total
        central=max(0.0,1.0-abs(center-0.5)*2.0)*5.0
        score=min(motion/10.0,1.0)*95.0 + central

        candidates.append({
            "start":round(start,3),
            "source_duration":total,
            "target_duration":target_duration,
            "score":round(score,3),
            "motion":round(motion,3),
            "mode":"fast",
            "reason":"fast_motion_scan"
        })

    return max(candidates,key=lambda x:x["score"])

def trim_video_to_duration(input_path,output_path,duration,width=1920,height=1080,
                           smart_cut=True,smart_cut_samples=3,head_tail_margin=0.35,
                           smart_cut_mode="fast",probe_seconds=1.35,minimum_ratio=1.65):
    input_path=Path(input_path)
    output_path=Path(output_path)
    output_path.parent.mkdir(parents=True,exist_ok=True)

    total=media_duration(input_path)
    segment={"start":0.0,"source_duration":total,"target_duration":duration,
             "score":0.0,"mode":"off","reason":"simple_cut"}

    if smart_cut and smart_cut_mode=="fast":
        segment=choose_fast_segment(
            input_path,duration,
            samples=int(smart_cut_samples),
            probe_seconds=float(probe_seconds),
            minimum_ratio=float(minimum_ratio)
        )
    elif smart_cut and smart_cut_mode=="center" and total and total>duration:
        segment["start"]=round((total-duration)/2,3)
        segment["mode"]="center"
        segment["reason"]="center_cut"

    vf="scale='if(gt(a,16/9),-2,1920)':'if(gt(a,16/9),1080,-2)',crop=1920:1080"

    cmd=[
        _which("ffmpeg"),"-y",
        "-ss",f"{segment['start']:.3f}",
        "-i",str(input_path),
        "-t",f"{duration:.3f}",
        "-vf",vf,
        "-c:v","libx264",
        "-preset","ultrafast",
        "-crf","21",
        "-pix_fmt","yuv420p",
        "-an",
        str(output_path)
    ]
    _run(cmd,check=True)
    return str(output_path),segment

def image_to_video(input_path,output_path,duration,width=1920,height=1080,fps=30):
    input_path=Path(input_path)
    output_path=Path(output_path)
    output_path.parent.mkdir(parents=True,exist_ok=True)

    frames=max(1,int(round(duration*fps)))
    vf=(
        "scale=1920:1080:force_original_aspect_ratio=increase,"
        "crop=1920:1080,"
        f"zoompan=z='min(zoom+0.0008,1.08)':"
        f"x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':"
        f"d={frames}:s=1920x1080:fps={fps}"
    )
    cmd=[
        _which("ffmpeg"),"-y","-loop","1","-i",str(input_path),
        "-vf",vf,"-t",f"{duration:.3f}",
        "-c:v","libx264","-preset","ultrafast","-crf","21",
        "-pix_fmt","yuv420p","-an",str(output_path)
    ]
    _run(cmd,check=True)
    return str(output_path)
