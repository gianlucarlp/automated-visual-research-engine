import re,requests,hashlib,html
from pathlib import Path

TARGET=16/9

def clean_html(text):
    return re.sub(r"<[^>]+>"," ",html.unescape(str(text or ""))).strip()

def assess_16_9(w,h,tolerance=.14):
    if not w or not h:
        return False,False,"sem dimensões"
    if h>w:
        return False,False,"vertical"
    ratio=w/h
    delta=abs(ratio-TARGET)/TARGET
    if delta<=.035:
        return True,False,"16:9"
    if delta<=tolerance:
        return True,True,"crop 16:9"
    return False,False,"proporção incompatível"

def score(item,query,preferred="either"):
    ok,crop,_=assess_16_9(item.get("width"),item.get("height"))
    if not ok:
        return -1
    words=[x.lower() for x in re.findall(r"[A-Za-zÀ-ÿ0-9]+",query) if len(x)>2]
    text=" ".join(str(item.get(k,"")) for k in ["title","description","tags"]).lower()
    hits=sum(1 for w in words if w in text)
    semantic=min(60,hits*12)

    w=item.get("width") or 0
    quality=25 if w>=1920 else 18 if w>=1280 else 10 if w>=854 else 4

    media_type=item.get("media_type","video")
    preference=0
    if preferred=="video" and media_type=="video": preference=12
    elif preferred in ("image","archival") and media_type=="image": preference=12
    elif preferred=="either": preference=5

    archival_bonus=0
    if preferred=="archival" and item.get("provider")=="Wikimedia Commons":
        archival_bonus=15

    crop_penalty=5 if crop else 0
    duration=item.get("duration") or 0
    duration_bonus=6 if media_type=="video" and duration>=6 else 0

    return max(0,semantic+quality+preference+archival_bonus+duration_bonus-crop_penalty)

def cache_key(provider,media_type,query):
    return hashlib.sha1(f"{provider}|{media_type}|{query}".encode("utf-8")).hexdigest()

def download(url,path):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    with requests.get(url,stream=True,timeout=180,
                      headers={"User-Agent":"SRT-Documentary-Media-Mapper/5.0"}) as r:
        r.raise_for_status()
        with path.open("wb") as f:
            for chunk in r.iter_content(1024*512):
                if chunk:
                    f.write(chunk)
    return str(path)

def extension_for(item):
    url=(item.get("url") or "").lower().split("?")[0]
    if item.get("media_type")=="video":
        for ext in [".mp4",".webm",".ogv",".mov"]:
            if url.endswith(ext): return ext
        return ".mp4"
    for ext in [".jpg",".jpeg",".png",".webp",".tif",".tiff"]:
        if url.endswith(ext): return ".jpg" if ext==".jpeg" else ext
    return ".jpg"
