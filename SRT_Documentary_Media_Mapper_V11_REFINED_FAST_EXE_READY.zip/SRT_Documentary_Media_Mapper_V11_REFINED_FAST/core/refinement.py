import re

def _tokens(text):
    return set(x.lower() for x in re.findall(r"[A-Za-zÀ-ÿ0-9]+", str(text or "")) if len(x) > 2)

def semantic_overlap(candidate, must_have, avoid):
    text = " ".join(str(candidate.get(k,"")) for k in ("title","description","tags","query")).lower()
    score = 0.0

    must_tokens=set()
    avoid_tokens=set()
    for x in must_have or []:
        must_tokens |= _tokens(x)
    for x in avoid or []:
        avoid_tokens |= _tokens(x)

    if must_tokens:
        hits=sum(1 for t in must_tokens if t in text)
        score += min(30.0,(hits/max(1,len(must_tokens)))*30.0)

    if avoid_tokens:
        bad=sum(1 for t in avoid_tokens if t in text)
        score -= min(35.0,bad*12.0)

    return score

def apply_refinement(candidates,must_have=None,avoid=None,used_urls=None,recent_provider_types=None,diversity=True):
    used_urls=used_urls or set()
    refined=[]
    for item in candidates:
        url=item.get("url")
        if url and url in used_urls:
            continue

        score=float(item.get("score",0))+semantic_overlap(item,must_have or [],avoid or [])

        if diversity and recent_provider_types:
            sig=f"{item.get('provider')}:{item.get('media_type')}"
            repeats=sum(1 for x in recent_provider_types if x==sig)
            score -= min(20,repeats*5)

        x=dict(item)
        x["refined_score"]=round(score,3)
        x["confidence"]=round(max(0,min(100,score)),1)
        refined.append(x)

    refined.sort(key=lambda x:x["refined_score"], reverse=True)
    return refined

def build_query_ladder(info,primary,fallback,max_levels=3):
    ladder=[]
    explicit=info.get("query_ladder") or []
    for level in explicit:
        if isinstance(level,list) and level:
            ladder.append(level)

    if not ladder:
        if primary:
            ladder.append(primary[:2])
            if len(primary)>2:
                ladder.append(primary[2:4])
        if fallback:
            ladder.append(fallback[:2])

    out=[]
    for level in ladder[:max_levels]:
        seen=[]
        for q in level:
            q=str(q).strip()
            if q and q not in seen:
                seen.append(q)
        if seen:
            out.append(seen)
    return out
