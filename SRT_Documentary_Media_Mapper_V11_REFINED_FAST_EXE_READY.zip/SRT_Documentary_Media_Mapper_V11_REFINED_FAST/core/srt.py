import re
from dataclasses import dataclass

TIME = re.compile(r"(\d{2}):(\d{2}):(\d{2}),(\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2}),(\d{3})")

@dataclass
class Subtitle:
    index: int
    start: float
    end: float
    text: str

@dataclass
class Scene:
    id: int
    start: float
    end: float
    text: str
    duration: float

def _sec(h,m,s,ms):
    return int(h)*3600 + int(m)*60 + int(s) + int(ms)/1000

def parse_srt(path):
    raw = open(path, "r", encoding="utf-8-sig").read()
    blocks = re.split(r"\n\s*\n", raw.strip())
    out=[]
    for block in blocks:
        lines=[x.strip() for x in block.splitlines() if x.strip()]
        if len(lines) < 3:
            continue
        m=TIME.search(lines[1])
        if not m:
            continue
        try:
            idx=int(lines[0])
        except:
            idx=len(out)+1
        out.append(Subtitle(idx,_sec(*m.groups()[:4]),_sec(*m.groups()[4:])," ".join(lines[2:])))
    return out

def build_scenes(subs,max_seconds=12):
    scenes=[]
    cur=[]
    for s in subs:
        if not cur:
            cur=[s]
            continue
        if s.end-cur[0].start <= max_seconds:
            cur.append(s)
        else:
            scenes.append(Scene(len(scenes)+1,cur[0].start,cur[-1].end,
                                " ".join(x.text for x in cur),round(cur[-1].end-cur[0].start,3)))
            cur=[s]
    if cur:
        scenes.append(Scene(len(scenes)+1,cur[0].start,cur[-1].end,
                            " ".join(x.text for x in cur),round(cur[-1].end-cur[0].start,3)))
    return scenes
